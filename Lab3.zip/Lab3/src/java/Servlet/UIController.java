
package Servlet;

import DAO.Person;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import DAO.*;
import java.util.List;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Locale;
import com.mysql.jdbc.Driver;
import java.sql.Date;
import java.sql.SQLException;
import javax.annotation.Resource;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;


public class UIController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Resource(name = "jdbc/lab3")
    private DataSource ds;
    
    public UIController() throws NamingException {
		InitialContext ctx = new InitialContext();
		ds = (DataSource) ctx.lookup("jdbc/lab3");
	}
    
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) {
       try {
            DAO dao = new DAO(ds);
            String action = request.getParameter("action");
            switch (action) {
                case "view":
                    {
                        List<Person> persons = dao.PersonGetAll();
                        request.setAttribute("person", persons);
                        request.getRequestDispatcher("listPerson.jsp").forward(request, response);
                        break;
                    }
                case "insert":
                    {
                        Person person = new Person();
                        person.setId(Integer.valueOf(request.getParameter("id")));
                        person.setFname(request.getParameter("fname"));
                        person.setLname(request.getParameter("lname"));
                        person.setBdate(Date.valueOf(request.getParameter("bdate")));
                        person.setFnum(Integer.valueOf(request.getParameter("fnum")));
                        dao.PersonCreate(person);
                        request.getRequestDispatcher("listPerson.jsp").forward(request, response);
                        break;
                    }
                case "delete":
                    {
                        Person person = new Person();
                        person.setId(Integer.valueOf(request.getParameter("id")));
                        dao.PersonDelete(person);
                        request.getRequestDispatcher("listPerson.jsp").forward(request, response);
                        break;
                    }
                default:
                    break;
            }
        } catch (SQLException | ServletException | IOException | NumberFormatException ex) {
            ex.printStackTrace();
        }
    }

    
    
    
    
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
   

