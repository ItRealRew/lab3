package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;


public class DAO {
    DataSource ds;
    Connection connection;
    
    public DAO(DataSource ds) {
        this.ds = ds;
    }
    
    public Connection openConnection() throws SQLException {  
        try {            
            connection =  ds.getConnection();         
        } catch (SQLException ex) {
            throw new RuntimeException("Can't open connection ERROR = " + ex.getMessage(), ex);
        }
        return connection;
    }
    
    public void PersonCreate(Object o) throws SQLException {
        connection = openConnection();
        Person person = (Person) o;
        String sql = "INSERT INTO `person` (id, first_name, last_name, birthdate, fnum) VALUES (?,?,?,?,?)";
        PreparedStatement stm = connection.prepareStatement(sql);
        stm.setInt(1, person.getId());
        stm.setString(2, person.getFname());
        stm.setString(3, person.getLname());
        stm.setDate(4, person.getBdate());
        stm.setInt(5, person.getFnum());
        stm.executeUpdate();
    }
    
    public Person PersonGetById(int id) throws SQLException {
        connection = openConnection();
        String sql = "SELECT * FROM `person` WHERE id = ?;";
        PreparedStatement stm = connection.prepareStatement(sql);
        stm.setInt(1, id);
        ResultSet rs = stm.executeQuery();
        rs.next();
        Person person = new Person();
        person.setId(rs.getInt("id"));
        person.setFname(rs.getString("first_name"));
        person.setLname(rs.getString("last_name"));
        person.setBdate(rs.getDate("birthdate"));
        person.setFnum(rs.getInt("fnum"));
        return person;
    }
    
    
    public void PersonDelete(Object o) throws SQLException {
        connection = openConnection();
        Person person = (Person) o;
        String sql = "DELETE FROM `person` WHERE id=?";
        PreparedStatement stm = connection.prepareStatement(sql);
        stm.setInt(1, person.getId());
        stm.executeUpdate();
    }

    public List<Person> PersonGetAll() throws SQLException {
        connection = openConnection();
        String sql = "SELECT * FROM `person`;";
        PreparedStatement stm = connection.prepareStatement(sql);
        ResultSet rs = stm.executeQuery();
        List<Person> list = new ArrayList<>();
        while (rs.next()) {
            Person person = new Person();
            person.setId(rs.getInt("id"));
            person.setFname(rs.getString("first_name"));
            person.setLname(rs.getString("last_name"));
            person.setBdate(rs.getDate("birthdate"));
            person.setFnum(rs.getInt("fnum"));
            list.add(person);
        }
        return list;
    }

    public void PersonUpdate(Object o) throws SQLException {
        connection = openConnection();
        Person person = (Person) o;
        String sql = "UPDATE `person` SET first_name=? WHERE id=?";
        PreparedStatement stm = connection.prepareStatement(sql);
        stm.setString(1, person.getFname());
        stm.setInt(2, person.getId());
        stm.executeUpdate();
    }
}
