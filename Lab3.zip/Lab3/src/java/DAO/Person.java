
package DAO;

import java.sql.Date;


public class Person {
    private int id;
    private String fname;
    private String lname;
    private Date bdate;
    private int fnum;

    @Override
   public String toString() {
       return id + " " + fname + " " + lname + " " + bdate + " " + fnum;
   }
    
    public int getId() {
        return id;
    }

   
    public void setId(int id) {
        this.id = id;
    }

    
    public String getFname() {
        return fname;
    }

    
    public void setFname(String fname) {
        this.fname = fname;
    }

    
    public String getLname() {
        return lname;
    }

    
    public void setLname(String lname) {
        this.lname = lname;
    }

    
    public Date getBdate() {
        return bdate;
    }

    
    public void setBdate(Date bdate) {
        this.bdate = bdate;
    }

    
    public int getFnum() {
        return fnum;
    }

    
    public void setFnum(int fnum) {
        this.fnum = fnum;
    }
}
